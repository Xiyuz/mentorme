```json
{
    "first_name": "test",
    "last_name": "test",
    "email": "t1@sfu.ca",
    "school": "sfu",
    "degree": "bachelor",
    "year_in_school": "freshman",
    "major": "cs",
    "department": "ap",
    "available_date": "Mon",
    "user_name": "ysj"

}
```