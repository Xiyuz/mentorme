## Install Helm on Kubernetes

1. install Helm 3
2. Add `stable` to Helm repo
  `helm add repo stable https://kubernetes-charts.storage.googleapis.com`
3. Add 
